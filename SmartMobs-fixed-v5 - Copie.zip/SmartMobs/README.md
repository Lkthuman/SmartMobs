# SmartMobs - IA adaptative pour Minecraft 1.21.1 (NeoForge)

Les mobs observent le joueur, apprennent et adaptent leur stratégie.

## Fonctionnalités

- **Réaction instantanée à l'arme** : un mob qui te voit tenir une épée, un arc ou un bouclier s'adapte tout de suite (flanc, zigzag, contournement, recul, mise à couvert...) et se réadapte dès que tu changes d'objet.
- **Creeper furtif** : un creeper que tu regardes devient invisible, s'approche discrètement et redevient visible juste avant d'exploser.
- **Apprentissage progressif** : 9 stratégies (couverture, flanc, encerclement, pilier, escalade, retraite...) débloquées selon ton style de jeu et le temps passé à t'observer.
- **Golem anti-pilier** : le golem de fer casse les blocs sous un joueur qui monte un pilier hors de portée.
- **Multijoueur compatible**, tout est configurable dans `smartmobs-common.toml`.

Commandes : `/smartmobs debug | stats | reset | reload`

## Prérequis

Minecraft 1.21.1, NeoForge 21.1.x, Java 21.

## Compilation

```bash
./gradlew build        # Windows : gradlew.bat build
```

Le JAR se trouve dans `build/libs/smartmobs-1.0.1.jar` : à placer dans le dossier `mods`.

Voir `README_COMPLET.md` et `GUIDE_UTILISATION.md` pour les détails, `CHANGELOG.md` pour l'historique. Licence MIT.
