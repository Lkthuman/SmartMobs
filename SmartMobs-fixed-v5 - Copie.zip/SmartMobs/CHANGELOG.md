# Changelog - SmartMobs

## [1.0.1] - 2026-10-08

### ✨ Nouveautés
- **Réaction instantanée à l'arme** (`WeaponReactionGoal`, option `weapon_reaction`) : dès qu'un mob qui te cible voit ce que tu tiens, il s'adapte sans délai d'apprentissage, et se réadapte immédiatement si tu changes d'objet.
  - Zombie / Husk / Drowned / Araignée / Vindicator / Enderman : épée ou hache → flanc puis charge ; arc / arbalète / trident → rush en zigzag ; bouclier → contournement pour te prendre dans le dos ; blocs en main → rush avant que tu ne montes un pilier.
  - Squelette / Stray / Pillager / Witch : épée ou hache → recul (kiting) puis tir ; arc → mise à couvert puis sortie pour tirer ; bouclier → se place derrière toi.
- **Creeper furtif** (`CreeperStealthGoal`, options `creeper_stealth`, `creeper_stealth_range`) : un creeper qui te cible et que tu regardes devient invisible, s'approche discrètement (en passant par ton dos s'il est loin) et redevient visible juste avant d'exploser (≈3,6 blocs, mèche allumée, ou s'il est touché).
- `/smartmobs debug` affiche l'arme vue par le mob, la réaction en cours et l'état furtif du creeper.

### 🐛 Corrections
- Les stratégies d'adaptation étaient inefficaces : elles recalculaient un chemin à chaque tick et se battaient avec les goals vanilla. Elles prennent désormais le contrôle du mouvement de façon exclusive (flag MOVE) pendant leur durée, avec chemins recalculés par intervalles.
- SEEK_COVER ne trouvait jamais d'abri (test de ligne de vue faux) : nouvelle recherche d'une position réellement cachée au joueur.
- BUILD_UP ne posait quasiment jamais de bloc : le zombie fait maintenant un vrai « pillar » (saut + bloc sous les pieds), uniquement si `mobGriefing` est actif.
- Cooldowns des stratégies basés sur l'heure réelle au lieu des ticks de jeu : corrigé (ticks de jeu).
- Les échecs de stratégie n'étaient jamais enregistrés : les stratégies qui échouent sont maintenant choisies moins souvent.
- Les options `adaptation_chance` et `strategy_cooldown` n'étaient pas utilisées : elles le sont maintenant.
- RETREAT / PATH_REEVALUATION / CLIMB / ANTI_RANGED / ANTI_HIGH_GROUND s'activaient dans de mauvaises conditions : conditions d'activation corrigées (PV bas, blocage de pathfinding, arme à distance...).
- Détection d'arme du joueur par nom de classe → remplacée par une vraie détection (épée, hache, masse, arc, arbalète, trident, bouclier, blocs). Seuls les combats contre des monstres comptent.
- Le comportement mémorisé du joueur s'estompe maintenant avec le temps.
- Suppression de code mort qui pouvait planter (`MobEventHandler`, `MobEvents`, `SmartMobsCommand` dupliquée).

### 🧹 Nettoyage
- Projet allégé : 74 fichiers au lieu de plus de 100. Retrait des faux JAR (`dist/`, `releases/`), des guides de publication redondants, des scripts de build (`gradlew build` suffit), de `.github/`, du doublon `src/main/templates`, de l'icône vide, et de l'ancien système d'apprentissage parallèle jamais utilisé (`LearningSystem`, `AdaptationManager`, `MobAdaptation`, etc.).
- Version passée à 1.0.1 (`build.gradle` et `neoforge.mods.toml`).

## [1.0.0] - 2026-10-07

### ✨ Features
- ✅ Système d'apprentissage des mobs
- ✅ Détection du comportement du joueur
  - Utilisation de l'arc/arbalète
  - Combat au mêlée
  - Construction
  - Combat en hauteur
- ✅ Système de mémoire persistant
- ✅ 4 niveaux d'adaptation (LOW, NORMAL, SMART, VERY_SMART)
- ✅ Stratégies d'adaptation :
  - Anti-Ranged (Éviter les projectiles)
  - Anti-High-Ground (Gérer les hauteurs)
  - Climb (Monter)
  - Cover (Chercher un abri)
- ✅ Commandes de debug et administration
- ✅ Configuration flexible
- ✅ Support multijoueur
- ✅ Compatible vanilla Minecraft

### 🐛 Bug Fixes
- Pas de bugs critiques identifiés en v1.0.0

### 🔧 Technical
- Minecraft 1.21.1 / NeoForge 1.21.1
- Java 21
- Gradle build system

---

## Roadmap Futures Versions

### [1.1.0] - TBD
- [ ] Plus de stratégies d'adaptation
- [ ] Animations améliorées
- [ ] Interface utilisateur optionnelle
- [ ] Compatibilité avec mods customs
- [ ] Meilleure documentation

### [1.2.0] - TBD
- [ ] Adaptation par espèce de mob
- [ ] Niveaux d'apprentissage plus granulaires
- [ ] Télémétrie optionnelle
- [ ] Optimisations de performance

### [2.0.0] - TBD
- [ ] Système d'IA révolutionné
- [ ] Support complet des mods customs
- [ ] API publique pour les développeurs
- [ ] Outils avancés de debug
