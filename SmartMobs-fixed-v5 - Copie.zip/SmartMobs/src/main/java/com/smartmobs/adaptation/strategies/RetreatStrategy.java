package com.smartmobs.adaptation.strategies;

import com.smartmobs.adaptation.StrategyType;
import com.smartmobs.learning.AdvancedAnimations;
import com.smartmobs.util.MobFamily;
import com.smartmobs.util.PlayerScanner;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** A badly wounded mob breaks off the fight instead of dying for nothing. */
public class RetreatStrategy extends AbstractAdaptationStrategy {

    public RetreatStrategy() {
        super(StrategyType.RETREAT, 1, 180);
        this.maxActiveDuration = 60;
    }

    @Override
    public boolean canActivate(Mob mob, Player target) {
        return family(mob) != MobFamily.CREEPER
                && mob.getHealth() < mob.getMaxHealth() * 0.35F
                && getDistance(mob, target) < 8.0;
    }

    @Override
    public void execute(Mob mob, Player target) {
        incrementActiveDuration();

        if (activeDuration == 1) {
            AdvancedAnimations.nervousAnimation(mob);
        }

        Vec3 away = PlayerScanner.flatDirection(target, mob).scale(6.0);
        moveTo(mob, mob.getX() + away.x, mob.getY(), mob.getZ() + away.z, 1.3);
    }

    @Override
    public boolean shouldContinue(Mob mob, Player target) {
        return getDistance(mob, target) < 10.0 && !isActiveDurationExceeded();
    }

    @Override
    public boolean wasSuccessful(Mob mob, Player player, double startDistance) {
        return mob.distanceTo(player) > startDistance + 2.0;
    }
}
