package com.smartmobs.adaptation.strategies;

import com.smartmobs.adaptation.MobMemory;
import com.smartmobs.adaptation.StrategyType;
import com.smartmobs.memory.PlayerBehavior;
import com.smartmobs.util.CoverFinder;
import com.smartmobs.util.MobFamily;
import com.smartmobs.util.PlayerScanner;
import com.smartmobs.util.WeaponClass;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;

/** The player shoots at us: hide behind a block that breaks his line of sight. */
public class SeekCoverStrategy extends AbstractAdaptationStrategy {

    private BlockPos cover = null;

    public SeekCoverStrategy() {
        super(StrategyType.SEEK_COVER, 1, 200);
        this.maxActiveDuration = 80;
    }

    @Override
    public boolean canActivate(Mob mob, Player target) {
        if (family(mob) == MobFamily.CREEPER) {
            return false;
        }
        double distance = getDistance(mob, target);
        return canSeeTarget(mob, target) && distance >= 5.0 && distance < 20.0;
    }

    @Override
    public boolean canActivate(Mob mob, Player target, MobMemory memory) {
        if (!canActivate(mob, target)) {
            return false;
        }
        PlayerBehavior behavior = PlayerScanner.behaviorOf(target);
        return PlayerScanner.classify(target) == WeaponClass.RANGED
                || behavior.getRangedUsage() >= 0.3f
                || behavior.getProjectileUsage() >= 0.3f;
    }

    @Override
    public void execute(Mob mob, Player target) {
        incrementActiveDuration();
        if (cover == null) {
            cover = CoverFinder.find(mob, target, 8);
        }
        if (cover != null) {
            animateSearch(mob);
            moveTo(mob, cover.getX() + 0.5, cover.getY(), cover.getZ() + 0.5, 1.2);
        }
    }

    @Override
    public boolean shouldContinue(Mob mob, Player target) {
        if (cover == null || isActiveDurationExceeded()) {
            return false;
        }
        return mob.distanceToSqr(cover.getX() + 0.5, cover.getY(), cover.getZ() + 0.5) > 2.25;
    }

    @Override
    public boolean wasSuccessful(Mob mob, Player player, double startDistance) {
        return !canSeeTarget(mob, player);
    }

    @Override
    public void onComplete(Mob mob) {
        super.onComplete(mob);
        cover = null;
    }
}
