package com.smartmobs.adaptation.strategies;

import com.smartmobs.adaptation.MobMemory;
import com.smartmobs.adaptation.StrategyType;
import com.smartmobs.memory.PlayerBehavior;
import com.smartmobs.util.MobFamily;
import com.smartmobs.util.PlayerScanner;
import com.smartmobs.util.WeaponClass;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** The player shoots from afar: close the gap in a zigzag so arrows miss. */
public class AntiRangedStrategy extends AbstractAdaptationStrategy {

    public AntiRangedStrategy() {
        super(StrategyType.ANTI_RANGED, 1, 150);
        this.maxActiveDuration = 100;
    }

    @Override
    public boolean canActivate(Mob mob, Player player) {
        return family(mob) == MobFamily.MELEE && getDistance(mob, player) > 8.0;
    }

    @Override
    public boolean canActivate(Mob mob, Player player, MobMemory memory) {
        if (!canActivate(mob, player)) {
            return false;
        }
        PlayerBehavior behavior = PlayerScanner.behaviorOf(player);
        return PlayerScanner.classify(player) == WeaponClass.RANGED
                || behavior.getRangedUsage() >= 0.3f
                || behavior.getProjectileUsage() >= 0.3f;
    }

    @Override
    public void execute(Mob mob, Player player) {
        incrementActiveDuration();
        Vec3 dir = PlayerScanner.flatDirection(mob, player);
        Vec3 perpendicular = new Vec3(-dir.z, 0.0, dir.x);
        double offset = Math.sin(activeDuration * 0.3) * 2.5;
        Vec3 destination = player.position().add(perpendicular.scale(offset));
        moveTo(mob, destination.x, destination.y, destination.z, 1.35);
    }

    @Override
    public boolean shouldContinue(Mob mob, Player player) {
        return getDistance(mob, player) > 3.0 && !isActiveDurationExceeded();
    }
}
