package com.smartmobs.adaptation;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;

/**
 * A strategy a mob can use to adapt to a player.
 * One instance exists PER MOB (strategies keep per-mob state: timers, targets...).
 */
public interface AdaptationStrategy {
    StrategyType getType();
    int getMinimumAdaptationLevel();
    int getCooldownTicks();

    boolean canActivate(Mob mob, Player player);

    /** Same as above, with access to what the mob remembers (e.g. "I keep getting stuck"). */
    default boolean canActivate(Mob mob, Player player, MobMemory memory) {
        return canActivate(mob, player);
    }

    /** Called once when the strategy takes control of the mob. */
    default void onStart(Mob mob, Player player) {}

    /** Called every tick while the strategy is running. */
    void execute(Mob mob, Player player);

    default boolean shouldContinue(Mob mob, Player player) { return true; }

    /** Used to learn: a strategy that keeps failing is picked less and less often. */
    default boolean wasSuccessful(Mob mob, Player player, double startDistance) {
        return mob.distanceTo(player) < startDistance - 1.0;
    }

    default void onComplete(Mob mob) {}
    default String getName() { return getType().name(); }
}
