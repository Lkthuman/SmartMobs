package com.smartmobs.adaptation.strategies;

import com.smartmobs.adaptation.AdaptationStrategy;
import com.smartmobs.adaptation.StrategyType;
import com.smartmobs.learning.LearningMoments;
import com.smartmobs.util.MobFamily;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;

public abstract class AbstractAdaptationStrategy implements AdaptationStrategy {

    protected StrategyType type;
    protected int minimumLevel;
    protected int cooldownTicks;
    protected int activeDuration = 0;
    protected int maxActiveDuration = 100;
    private int lastMoveAt = -100;

    public AbstractAdaptationStrategy(StrategyType type, int minimumLevel, int cooldownTicks) {
        this.type = type;
        this.minimumLevel = minimumLevel;
        this.cooldownTicks = cooldownTicks;
    }

    @Override
    public StrategyType getType() {
        return type;
    }

    @Override
    public int getMinimumAdaptationLevel() {
        return minimumLevel;
    }

    @Override
    public int getCooldownTicks() {
        return cooldownTicks;
    }

    @Override
    public void onStart(Mob mob, Player player) {
        activeDuration = 0;
        lastMoveAt = -100;
    }

    @Override
    public void onComplete(Mob mob) {
        activeDuration = 0;
        lastMoveAt = -100;
    }

    protected void incrementActiveDuration() {
        activeDuration++;
    }

    protected boolean isActiveDurationExceeded() {
        return activeDuration >= maxActiveDuration;
    }

    protected boolean canSeeTarget(Mob mob, Player player) {
        return mob.hasLineOfSight(player);
    }

    protected double getDistance(Mob mob, Player player) {
        return mob.distanceTo(player);
    }

    protected MobFamily family(Mob mob) {
        return MobFamily.of(mob);
    }

    protected boolean griefAllowed(Mob mob) {
        return mob.level().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING);
    }

    /**
     * Throttled navigation order: asking for a new path EVERY tick makes mobs jitter and costs a lot,
     * so a new path is only computed every few ticks (or sooner if the mob has nothing left to follow).
     */
    protected void moveTo(Mob mob, double x, double y, double z, double speed) {
        boolean due = activeDuration - lastMoveAt >= 8;
        boolean idle = mob.getNavigation().isDone() && activeDuration - lastMoveAt >= 3;
        if (due || idle) {
            lastMoveAt = activeDuration;
            mob.getNavigation().moveTo(x, y, z, speed);
        }
    }

    protected void moveTo(Mob mob, Entity entity, double speed) {
        moveTo(mob, entity.getX(), entity.getY(), entity.getZ(), speed);
    }

    /** Visible "searching" particles, but not every single tick. */
    protected void animateSearch(Mob mob) {
        if (activeDuration % 20 == 1) {
            LearningMoments.searchAnimation(mob);
        }
    }
}
