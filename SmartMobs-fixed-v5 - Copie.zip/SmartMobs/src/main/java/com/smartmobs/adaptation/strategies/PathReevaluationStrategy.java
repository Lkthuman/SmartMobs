package com.smartmobs.adaptation.strategies;

import com.smartmobs.adaptation.MobMemory;
import com.smartmobs.adaptation.StrategyType;
import com.smartmobs.learning.LearningMoments;
import com.smartmobs.util.MobFamily;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;

/** The direct path is blocked: look for another way to reach the player (any side that can be reached). */
public class PathReevaluationStrategy extends AbstractAdaptationStrategy {

    private Vec3 alternativePath = null;
    private int failedSearches = 0;
    private int searchDelay = 0;

    public PathReevaluationStrategy() {
        super(StrategyType.PATH_REEVALUATION, 1, 200);
        this.maxActiveDuration = 80;
    }

    @Override
    public boolean canActivate(Mob mob, Player target) {
        return family(mob) != MobFamily.CREEPER && getDistance(mob, target) > 4.0;
    }

    @Override
    public boolean canActivate(Mob mob, Player target, MobMemory memory) {
        return canActivate(mob, target) && memory.getFailedPathfindingAttempts() >= 2;
    }

    @Override
    public void execute(Mob mob, Player target) {
        incrementActiveDuration();

        if (alternativePath == null && --searchDelay <= 0) {
            LearningMoments.searchAnimation(mob);
            alternativePath = findAlternativePath(mob, target);
            searchDelay = 20;
            if (alternativePath == null) {
                failedSearches++;
            }
        }

        if (alternativePath != null) {
            moveTo(mob, alternativePath.x, alternativePath.y, alternativePath.z, 1.0);
        }
    }

    @Override
    public boolean shouldContinue(Mob mob, Player target) {
        return !isActiveDurationExceeded() && failedSearches < 3 && getDistance(mob, target) > 3.0;
    }

    @Override
    public void onComplete(Mob mob) {
        super.onComplete(mob);
        alternativePath = null;
        failedSearches = 0;
        searchDelay = 0;
    }

    /** Tries 8 spots around the player, starting from a random one, and keeps the first that can be walked to. */
    private Vec3 findAlternativePath(Mob mob, Player target) {
        int start = mob.getRandom().nextInt(8);
        for (int i = 0; i < 8; i++) {
            double angle = ((start + i) % 8) * (Math.PI / 4.0);
            Vec3 candidate = target.position().add(Math.cos(angle) * 3.0, 0.0, Math.sin(angle) * 3.0);
            Path path = mob.getNavigation().createPath(candidate.x, candidate.y, candidate.z, 0);
            if (path != null && path.canReach()) {
                return candidate;
            }
        }
        return null;
    }
}
