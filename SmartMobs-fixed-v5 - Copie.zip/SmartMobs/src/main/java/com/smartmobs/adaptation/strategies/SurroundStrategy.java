package com.smartmobs.adaptation.strategies;

import com.smartmobs.adaptation.StrategyType;
import com.smartmobs.learning.LearningMoments;
import com.smartmobs.util.MobFamily;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;

/** Circle round the player; each mob takes its own slot so a group really surrounds him. */
public class SurroundStrategy extends AbstractAdaptationStrategy {

    private double baseAngle = 0;

    public SurroundStrategy() {
        super(StrategyType.SURROUND, 3, 400);
        this.maxActiveDuration = 150;
    }

    @Override
    public boolean canActivate(Mob mob, Player target) {
        double distance = getDistance(mob, target);
        return family(mob) == MobFamily.MELEE && distance < 10.0 && distance > 2.5;
    }

    @Override
    public void execute(Mob mob, Player target) {
        incrementActiveDuration();

        if (activeDuration == 1) {
            // deterministic slot per mob (UUID) -> several mobs spread around the player
            baseAngle = ((mob.getUUID().hashCode() & 0xFFFF) / 65536.0) * Math.PI * 2;
            LearningMoments.adaptationFlashAnimation(mob);
        }

        double angle = baseAngle + activeDuration * 0.03;
        double radius = 2.8;
        double x = target.getX() + Math.cos(angle) * radius;
        double z = target.getZ() + Math.sin(angle) * radius;

        animateSearch(mob);
        moveTo(mob, x, target.getY(), z, 1.1);
    }

    @Override
    public boolean shouldContinue(Mob mob, Player target) {
        return getDistance(mob, target) < 12.0 && !isActiveDurationExceeded();
    }
}
