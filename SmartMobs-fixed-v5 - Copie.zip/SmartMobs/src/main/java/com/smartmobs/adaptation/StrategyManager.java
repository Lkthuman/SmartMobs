package com.smartmobs.adaptation;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import com.smartmobs.adaptation.strategies.*;
import com.smartmobs.config.SmartMobsConfig;

import java.util.ArrayList;
import java.util.List;

public class StrategyManager {

    // One set of strategy instances PER mob: strategies hold per-mob state (timers, targets...)
    private final List<AdaptationStrategy> allStrategies = List.of(
        new SeekCoverStrategy(),
        new AntiRangedStrategy(),
        new AntiHighGroundStrategy(),
        new FlankStrategy(),
        new SurroundStrategy(),
        new ClimbStrategy(),
        new RetreatStrategy(),
        new PathReevaluationStrategy(),
        new BuildUpStrategy()
    );

    private AdaptationStrategy currentStrategy = null;

    /**
     * Picks a strategy that is unlocked (adaptation level), off cooldown, applicable right now and
     * not penalised by past failures. Returns null when nothing fits.
     */
    public AdaptationStrategy selectStrategy(Mob mob, Player target, MobMemory memory) {
        long now = mob.level().getGameTime();
        int adaptLevel = memory.getAdaptationLevel();
        List<AdaptationStrategy> candidates = new ArrayList<>();

        for (AdaptationStrategy strategy : allStrategies) {
            if (strategy.getMinimumAdaptationLevel() > adaptLevel) {
                continue;
            }
            if (memory.isStrategyCooldown(strategy.getType(), scaledCooldown(strategy), now)) {
                continue;
            }
            if (!strategy.canActivate(mob, target, memory)) {
                continue;
            }
            if (mob.getRandom().nextFloat() > memory.getStrategyFailurePenalty(strategy.getType())) {
                continue;
            }
            candidates.add(strategy);
        }

        if (candidates.isEmpty()) {
            return null;
        }
        currentStrategy = candidates.get(mob.getRandom().nextInt(candidates.size()));
        return currentStrategy;
    }

    /** strategy_cooldown in the config scales every strategy's own cooldown (200 = default values). */
    private int scaledCooldown(AdaptationStrategy strategy) {
        double factor = SmartMobsConfig.COMMON.strategyCooldown.get() / 200.0;
        return (int) Math.max(1, strategy.getCooldownTicks() * factor);
    }

    public AdaptationStrategy getCurrentStrategy() {
        return currentStrategy;
    }

    public void clearStrategy() {
        currentStrategy = null;
    }
}
