package com.smartmobs.adaptation.strategies;

import com.smartmobs.adaptation.MobMemory;
import com.smartmobs.adaptation.StrategyType;
import com.smartmobs.learning.LearningMoments;
import com.smartmobs.util.MobFamily;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;

/** The player is above us and we are stuck: hop and scramble towards him. */
public class ClimbStrategy extends AbstractAdaptationStrategy {

    public ClimbStrategy() {
        super(StrategyType.CLIMB, 2, 200);
        this.maxActiveDuration = 100;
    }

    @Override
    public boolean canActivate(Mob mob, Player target) {
        return family(mob) != MobFamily.CREEPER
                && (target.getY() - mob.getY()) > 1.5
                && getDistance(mob, target) < 10.0;
    }

    @Override
    public boolean canActivate(Mob mob, Player target, MobMemory memory) {
        return canActivate(mob, target) && memory.getFailedPathfindingAttempts() >= 1;
    }

    @Override
    public void execute(Mob mob, Player target) {
        incrementActiveDuration();

        if (activeDuration % 15 == 0 && mob.onGround()) {
            mob.getJumpControl().jump();
            LearningMoments.actionAnimation(mob);
        }

        animateSearch(mob);
        moveTo(mob, target.getX(), target.getY(), target.getZ(), 1.0);
    }

    @Override
    public boolean shouldContinue(Mob mob, Player target) {
        return (target.getY() - mob.getY()) > 0.5 && !isActiveDurationExceeded();
    }
}
