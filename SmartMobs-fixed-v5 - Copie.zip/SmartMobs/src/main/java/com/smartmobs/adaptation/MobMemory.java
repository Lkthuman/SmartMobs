package com.smartmobs.adaptation;

import java.util.EnumMap;
import java.util.Map;
import java.util.UUID;

/** What one mob remembers about one player. All timers use GAME TICKS. */
public class MobMemory {
    private static final int MAX_LEARNED_LEVELS = 2;

    private final UUID mobId;
    private final UUID playerId;

    private final Map<StrategyType, Integer> strategyFailures = new EnumMap<>(StrategyType.class);
    private final Map<StrategyType, Long> strategyEndedAt = new EnumMap<>(StrategyType.class);
    private StrategyType currentStrategy = null;
    private int currentAdaptationLevel = 0;
    private int learnedLevels = 0;
    private int learningProgress = 0;
    private boolean justLearned = false;
    private long lastObservationTime = 0;
    private int failedPathfindingAttempts = 0;

    public MobMemory(UUID mobId, UUID playerId) {
        this.mobId = mobId;
        this.playerId = playerId;
    }

    // ---------------------------------------------------------------- strategies

    public void recordStrategyFailure(StrategyType strategy) {
        strategyFailures.merge(strategy, 1, (a, b) -> Math.min(4, a + b));
    }

    public void recordStrategySuccess(StrategyType strategy) {
        strategyFailures.computeIfPresent(strategy, (key, value) -> value <= 1 ? null : value - 1);
    }

    /** Chance (0.15 .. 1) that the strategy is kept in the running. */
    public float getStrategyFailurePenalty(StrategyType strategy) {
        int failures = strategyFailures.getOrDefault(strategy, 0);
        return Math.max(0.15f, 1.0f - failures * 0.25f);
    }

    public void setCurrentStrategy(StrategyType strategy, long gameTime) {
        this.currentStrategy = strategy;
        this.lastObservationTime = gameTime;
    }

    public void markStrategyEnded(StrategyType strategy, long gameTime) {
        strategyEndedAt.put(strategy, gameTime);
        if (currentStrategy == strategy) {
            currentStrategy = null;
        }
    }

    public StrategyType getCurrentStrategy() {
        return currentStrategy;
    }

    public boolean isStrategyCooldown(StrategyType strategy, int cooldownTicks, long gameTime) {
        Long endedAt = strategyEndedAt.get(strategy);
        return endedAt != null && gameTime - endedAt < cooldownTicks;
    }

    // ---------------------------------------------------------------- pathfinding

    public void recordPathfindingFailure() {
        failedPathfindingAttempts++;
    }

    public void decayPathfindingFailure() {
        if (failedPathfindingAttempts > 0) {
            failedPathfindingAttempts--;
        }
    }

    public void resetPathfindingFailures() {
        failedPathfindingAttempts = 0;
    }

    public int getFailedPathfindingAttempts() {
        return failedPathfindingAttempts;
    }

    // ---------------------------------------------------------------- learning

    /** Observing the player fills the bar; a full bar teaches the mob one extra adaptation level. */
    public void increaseLearningProgress(int amount) {
        learningProgress += Math.max(0, amount);
        if (learningProgress >= 100) {
            learningProgress = 0;
            if (learnedLevels < MAX_LEARNED_LEVELS) {
                learnedLevels++;
                justLearned = true;
            }
        }
    }

    public int getLearningProgress() {
        return learningProgress;
    }

    public int getLearnedLevels() {
        return learnedLevels;
    }

    /** True once after the mob learned something new (used to trigger the visible animation). */
    public boolean consumeLearned() {
        boolean result = justLearned;
        justLearned = false;
        return result;
    }

    public void setAdaptationLevel(int level) {
        this.currentAdaptationLevel = Math.max(0, level);
    }

    public int getAdaptationLevel() {
        return currentAdaptationLevel;
    }

    public UUID getMobId() {
        return mobId;
    }

    public UUID getPlayerId() {
        return playerId;
    }

    public long getLastObservationTime() {
        return lastObservationTime;
    }
}
