package com.smartmobs.adaptation.strategies;

import com.smartmobs.adaptation.StrategyType;
import com.smartmobs.learning.LearningMoments;
import com.smartmobs.util.MobFamily;
import com.smartmobs.util.PlayerScanner;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Attack from the side instead of head-on. */
public class FlankStrategy extends AbstractAdaptationStrategy {

    private int flankDirection = 1;

    public FlankStrategy() {
        super(StrategyType.FLANK, 2, 250);
        this.maxActiveDuration = 100;
    }

    @Override
    public boolean canActivate(Mob mob, Player target) {
        double distance = getDistance(mob, target);
        return family(mob) == MobFamily.MELEE && distance < 12.0 && distance > 4.0;
    }

    @Override
    public void execute(Mob mob, Player target) {
        incrementActiveDuration();

        if (activeDuration == 1) {
            flankDirection = mob.getRandom().nextBoolean() ? 1 : -1;
            LearningMoments.adaptationFlashAnimation(mob);
        }

        Vec3 toTarget = PlayerScanner.flatDirection(mob, target);
        Vec3 perpendicular = new Vec3(-toTarget.z * flankDirection, 0.0, toTarget.x * flankDirection);
        Vec3 flankPos = target.position().add(perpendicular.scale(3.5));

        animateSearch(mob);
        moveTo(mob, flankPos.x, flankPos.y, flankPos.z, 1.2);
    }

    @Override
    public boolean shouldContinue(Mob mob, Player target) {
        double distance = getDistance(mob, target);
        return distance < 15.0 && distance > 2.5 && !isActiveDurationExceeded();
    }
}
