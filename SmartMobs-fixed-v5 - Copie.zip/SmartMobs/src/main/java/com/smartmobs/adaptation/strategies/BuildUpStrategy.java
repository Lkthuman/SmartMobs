package com.smartmobs.adaptation.strategies;

import com.smartmobs.adaptation.MobMemory;
import com.smartmobs.adaptation.StrategyType;
import com.smartmobs.learning.AdvancedAnimations;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;

/**
 * The player sits out of reach and the mob is stuck: zombies pillar up like a player would
 * (jump, drop a block under their feet, repeat). Needs the mobGriefing gamerule.
 */
public class BuildUpStrategy extends AbstractAdaptationStrategy {

    private static final int MAX_BLOCKS = 10;

    private int blocksPlaced = 0;
    private double jumpStartY = 0;
    private boolean jumping = false;
    private int placeCooldown = 0;

    public BuildUpStrategy() {
        super(StrategyType.BUILD_UP, 2, 500);
        this.maxActiveDuration = 240;
    }

    @Override
    public boolean canActivate(Mob mob, Player target) {
        if (!(mob instanceof Zombie) || !griefAllowed(mob)) {
            return false;
        }
        double dx = target.getX() - mob.getX();
        double dz = target.getZ() - mob.getZ();
        return (target.getY() - mob.getY()) > 2.5 && Math.sqrt(dx * dx + dz * dz) < 16.0;
    }

    @Override
    public boolean canActivate(Mob mob, Player target, MobMemory memory) {
        return canActivate(mob, target) && memory.getFailedPathfindingAttempts() >= 2;
    }

    @Override
    public void onStart(Mob mob, Player target) {
        super.onStart(mob, target);
        blocksPlaced = 0;
        jumping = false;
        placeCooldown = 0;
        AdvancedAnimations.thinkingAnimation(mob);
    }

    @Override
    public void execute(Mob mob, Player target) {
        incrementActiveDuration();

        double dx = target.getX() - mob.getX();
        double dz = target.getZ() - mob.getZ();
        if (Math.sqrt(dx * dx + dz * dz) > 2.0) {
            // first walk to the foot of the player's perch
            moveTo(mob, target.getX(), mob.getY(), target.getZ(), 1.1);
            return;
        }

        mob.getNavigation().stop();
        mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (placeCooldown > 0) {
            placeCooldown--;
        }

        if (mob.onGround()) {
            jumping = false;
            if (placeCooldown <= 0 && blocksPlaced < MAX_BLOCKS) {
                jumpStartY = mob.getY();
                mob.getJumpControl().jump();
                jumping = true;
            }
        } else if (jumping && mob.getY() >= jumpStartY + 1.0) {
            // risen a full block: drop one where the feet were
            BlockPos feet = BlockPos.containing(mob.getX(), jumpStartY + 0.1, mob.getZ());
            if (mob.level().getBlockState(feet).canBeReplaced()) {
                mob.level().setBlockAndUpdate(feet, Blocks.COBBLESTONE.defaultBlockState());
                blocksPlaced++;
                AdvancedAnimations.blockPlaceAnimation(mob);
            }
            jumping = false;
            placeCooldown = 6;
        }
    }

    @Override
    public boolean shouldContinue(Mob mob, Player target) {
        return (target.getY() - mob.getY()) > 1.2 && !isActiveDurationExceeded() && blocksPlaced < MAX_BLOCKS;
    }

    @Override
    public boolean wasSuccessful(Mob mob, Player player, double startDistance) {
        return blocksPlaced > 0 || mob.distanceTo(player) < startDistance - 1.0;
    }

    @Override
    public void onComplete(Mob mob) {
        super.onComplete(mob);
        blocksPlaced = 0;
        jumping = false;
        placeCooldown = 0;
    }
}
