package com.smartmobs.adaptation.strategies;

import com.smartmobs.adaptation.StrategyType;
import com.smartmobs.util.MobFamily;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;

/** The player stands higher than us: gather at the foot of his perch instead of wandering around. */
public class AntiHighGroundStrategy extends AbstractAdaptationStrategy {

    public AntiHighGroundStrategy() {
        super(StrategyType.ANTI_HIGH_GROUND, 2, 200);
        this.maxActiveDuration = 120;
    }

    @Override
    public boolean canActivate(Mob mob, Player player) {
        return family(mob) != MobFamily.CREEPER
                && player.getY() > mob.getY() + 2.0
                && getDistance(mob, player) < 30.0;
    }

    @Override
    public void execute(Mob mob, Player player) {
        incrementActiveDuration();
        animateSearch(mob);
        // ground navigation drops the destination down to the floor below the player
        moveTo(mob, player.getX(), player.getY(), player.getZ(), 1.2);
    }

    @Override
    public boolean shouldContinue(Mob mob, Player player) {
        double dx = player.getX() - mob.getX();
        double dz = player.getZ() - mob.getZ();
        boolean stillBelow = player.getY() > mob.getY() + 1.5;
        return stillBelow && Math.sqrt(dx * dx + dz * dz) > 2.0 && !isActiveDurationExceeded();
    }
}
