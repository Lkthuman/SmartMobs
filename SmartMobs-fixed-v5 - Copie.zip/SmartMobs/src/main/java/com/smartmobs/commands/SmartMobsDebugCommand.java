package com.smartmobs.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.player.Player;
import com.smartmobs.adaptation.MobMemory;
import com.smartmobs.ai.AdaptiveGoal;
import com.smartmobs.ai.CreeperStealthGoal;
import com.smartmobs.ai.PillarBreakerGoal;
import com.smartmobs.ai.WeaponReactionGoal;
import com.smartmobs.memory.ModAttachments;
import com.smartmobs.memory.PlayerBehavior;
import com.smartmobs.util.PlayerScanner;

public class SmartMobsDebugCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
            Commands.literal("smartmobs")
                .then(Commands.literal("debug")
                    .executes(SmartMobsDebugCommand::executeDebug))
                .then(Commands.literal("stats")
                    .executes(SmartMobsDebugCommand::executeStats))
                .then(Commands.literal("reset")
                    .executes(SmartMobsDebugCommand::executeReset))
                .then(Commands.literal("reload")
                    .executes(SmartMobsDebugCommand::executeReload))
        );
    }

    private static boolean hasSmartGoal(Mob mob) {
        return findWrapped(mob, AdaptiveGoal.class) != null
                || findWrapped(mob, PillarBreakerGoal.class) != null
                || findWrapped(mob, WeaponReactionGoal.class) != null
                || findWrapped(mob, CreeperStealthGoal.class) != null;
    }

    private static int executeDebug(CommandContext<CommandSourceStack> context) {
        CommandSourceStack source = context.getSource();
        Player player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("§cThis command must be run by a player"));
            return 0;
        }

        // Nearest mob that actually carries a SmartMobs goal
        ServerLevel level = source.getLevel();
        Mob nearestMob = level.getEntitiesOfClass(
            Mob.class,
            player.getBoundingBox().inflate(24),
            SmartMobsDebugCommand::hasSmartGoal
        ).stream()
            .min((a, b) -> Double.compare(a.distanceTo(player), b.distanceTo(player)))
            .orElse(null);

        if (nearestMob == null) {
            source.sendFailure(Component.literal("§cNo SmartMobs-enabled mob within 24 blocks"));
            return 0;
        }

        String mobName = BuiltInRegistries.ENTITY_TYPE.getKey(nearestMob.getType()).toString();
        int distance = (int) nearestMob.distanceTo(player);
        StringBuilder sb = new StringBuilder();
        sb.append("§b=== Smart Mobs Debug ===\n");
        sb.append("§eMob: §f").append(mobName).append("\n");
        sb.append("§eDistance: §f").append(distance).append(" blocks\n");
        sb.append("§eYou hold: §f").append(PlayerScanner.classify(player).name()).append("\n");

        WrappedGoal adaptive = findWrapped(nearestMob, AdaptiveGoal.class);
        if (adaptive != null) {
            AdaptiveGoal goal = (AdaptiveGoal) adaptive.getGoal();
            MobMemory memory = goal.getMobMemory();
            int adaptLevel = memory == null ? 0 : memory.getAdaptationLevel();
            int learning = memory == null ? 0 : memory.getLearningProgress();
            int stuck = memory == null ? 0 : memory.getFailedPathfindingAttempts();
            sb.append("§eAdaptation Level: §f").append(adaptLevel).append("/3\n");
            sb.append("§eLearning Progress: §f").append(learning).append("%\n");
            sb.append("§eStuck counter: §f").append(stuck).append("\n");
            sb.append("§eStrategy: §f").append(goal.getCurrentStrategyName())
              .append(adaptive.isRunning() ? " (running)" : " (idle)").append("\n");
        }

        WrappedGoal reaction = findWrapped(nearestMob, WeaponReactionGoal.class);
        if (reaction != null) {
            WeaponReactionGoal goal = (WeaponReactionGoal) reaction.getGoal();
            sb.append("§eWeapon seen: §f").append(goal.getLastSeen() == null ? "none yet" : goal.getLastSeen().name()).append("\n");
            sb.append("§eWeapon reaction: §f").append(reaction.isRunning() ? goal.getReactionName() : "idle").append("\n");
        }

        WrappedGoal stealth = findWrapped(nearestMob, CreeperStealthGoal.class);
        if (stealth != null) {
            CreeperStealthGoal goal = (CreeperStealthGoal) stealth.getGoal();
            sb.append("§eCreeper stealth: §f").append(goal.isHidden() ? "HIDDEN (invisible)" : "visible").append("\n");
        }

        WrappedGoal pillar = findWrapped(nearestMob, PillarBreakerGoal.class);
        if (pillar != null) {
            PillarBreakerGoal goal = (PillarBreakerGoal) pillar.getGoal();
            sb.append("§eAnti-pillar goal: §f").append(pillar.isRunning() ? "ACTIVE" : "idle").append("\n");
            if (goal.isBreaking()) {
                sb.append("§eBreaking block: §f").append(goal.getBreakingPos().toShortString())
                  .append(" (").append(goal.getBreakPercent()).append("%)");
            }
        }

        final String message = sb.toString().stripTrailing();
        source.sendSuccess(() -> Component.literal(message), false);
        return 1;
    }

    private static int executeStats(CommandContext<CommandSourceStack> context) {
        CommandSourceStack source = context.getSource();
        Player player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("§cThis command must be run by a player"));
            return 0;
        }

        try {
            PlayerBehavior behavior = player.getData(ModAttachments.PLAYER_BEHAVIOR);
            if (behavior != null) {
                final String message =
                    "§b=== Your Behavior Stats ===\n" +
                    "§eMelee: §f" + String.format("%.1f%%", behavior.getMeleeUsage() * 100) + "\n" +
                    "§eRanged: §f" + String.format("%.1f%%", behavior.getRangedUsage() * 100) + "\n" +
                    "§eProjectile: §f" + String.format("%.1f%%", behavior.getProjectileUsage() * 100) + "\n" +
                    "§eBuilding: §f" + String.format("%.1f%%", behavior.getBuildingUsage() * 100) + "\n" +
                    "§eHigh Ground: §f" + String.format("%.1f%%", behavior.getHighGroundUsage() * 100) + "\n" +
                    "§ePillar blocks (recent): §f" + behavior.getPillarCount(player.level().getGameTime());
                source.sendSuccess(() -> Component.literal(message), false);
            } else {
                source.sendFailure(Component.literal("§cNo behavior data found"));
            }
        } catch (Exception e) {
            source.sendFailure(Component.literal("§cError reading behavior: " + e.getMessage()));
        }

        return 1;
    }

    private static int executeReset(CommandContext<CommandSourceStack> context) {
        CommandSourceStack source = context.getSource();
        Player player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("§cThis command must be run by a player"));
            return 0;
        }
        player.setData(ModAttachments.PLAYER_BEHAVIOR, new PlayerBehavior());
        source.sendSuccess(() -> Component.literal("§eYour behavior data has been reset"), false);
        return 1;
    }

    private static int executeReload(CommandContext<CommandSourceStack> context) {
        context.getSource().sendSuccess(
            () -> Component.literal("§eNeoForge reloads smartmobs-common.toml automatically when the file is saved"),
            false
        );
        return 1;
    }

    private static WrappedGoal findWrapped(Mob mob, Class<? extends Goal> type) {
        for (WrappedGoal wrapped : mob.goalSelector.getAvailableGoals()) {
            if (type.isInstance(wrapped.getGoal())) {
                return wrapped;
            }
        }
        return null;
    }
}
