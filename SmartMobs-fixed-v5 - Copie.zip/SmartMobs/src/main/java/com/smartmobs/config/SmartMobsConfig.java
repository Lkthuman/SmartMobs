package com.smartmobs.config;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class SmartMobsConfig {
    public static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.IntValue LEARNING_SPEED;
    public static final ModConfigSpec.IntValue ADAPTATION_CHANCE;
    public static final ModConfigSpec.IntValue MAX_ADAPTATION_LEVEL;
    public static final ModConfigSpec.IntValue STRATEGY_COOLDOWN;
    public static final ModConfigSpec.BooleanValue DEBUG_MODE;
    public static final ModConfigSpec.BooleanValue ENABLED;
    public static final ModConfigSpec.IntValue OBSERVATION_RANGE;
    public static final ModConfigSpec.BooleanValue GOLEM_BREAK_BLOCKS;
    public static final ModConfigSpec.BooleanValue WEAPON_REACTION;
    public static final ModConfigSpec.BooleanValue CREEPER_STEALTH;
    public static final ModConfigSpec.IntValue CREEPER_STEALTH_RANGE;

    /**
     * Compatibility view used by the AI code.
     * IMPORTANT: assigned at the END of the static block below, once every
     * value above has been defined. (Previously it was initialised before the
     * static block, so all of its fields were null -> NullPointerException.)
     */
    public static final Common COMMON;

    public static final class Common {
        public final ModConfigSpec.BooleanValue enabled = ENABLED;
        public final ModConfigSpec.IntValue observationRange = OBSERVATION_RANGE;
        public final ModConfigSpec.IntValue learningSpeed = LEARNING_SPEED;
        public final ModConfigSpec.IntValue maxAdaptationLevel = MAX_ADAPTATION_LEVEL;
        public final ModConfigSpec.IntValue adaptationChance = ADAPTATION_CHANCE;
        public final ModConfigSpec.IntValue strategyCooldown = STRATEGY_COOLDOWN;
        public final ModConfigSpec.BooleanValue debugMode = DEBUG_MODE;
        public final ModConfigSpec.BooleanValue golemBreakBlocks = GOLEM_BREAK_BLOCKS;
        public final ModConfigSpec.BooleanValue weaponReaction = WEAPON_REACTION;
        public final ModConfigSpec.BooleanValue creeperStealth = CREEPER_STEALTH;
        public final ModConfigSpec.IntValue creeperStealthRange = CREEPER_STEALTH_RANGE;
    }

    static {
        BUILDER.push("smart_mobs");
        ENABLED = BUILDER.comment("Enable SmartMobs").define("enabled", true);
        LEARNING_SPEED = BUILDER.comment("How fast mobs learn (1-10)").defineInRange("learning_speed", 5, 1, 10);
        ADAPTATION_CHANCE = BUILDER.comment("Chance to adapt (1-100)").defineInRange("adaptation_chance", 30, 1, 100);
        MAX_ADAPTATION_LEVEL = BUILDER.comment("Maximum adaptation level").defineInRange("max_adaptation_level", 3, 1, 5);
        STRATEGY_COOLDOWN = BUILDER.comment("Cooldown between strategy changes").defineInRange("strategy_cooldown", 200, 20, 1000);
        OBSERVATION_RANGE = BUILDER.comment("Range at which mobs observe players").defineInRange("observation_range", 32, 4, 128);
        DEBUG_MODE = BUILDER.comment("Enable debug logging").define("debug_mode", false);
        GOLEM_BREAK_BLOCKS = BUILDER.comment("Iron golems break the blocks under a player who pillars up out of their reach (needs the mobGriefing gamerule)").define("golem_break_blocks", true);
        WEAPON_REACTION = BUILDER.comment("Mobs adapt INSTANTLY to what the player holds (sword -> flank, bow -> zigzag / cover, shield -> go behind...)").define("weapon_reaction", true);
        CREEPER_STEALTH = BUILDER.comment("A creeper that is spotted turns invisible, sneaks up on the player and reveals itself right before exploding").define("creeper_stealth", true);
        CREEPER_STEALTH_RANGE = BUILDER.comment("Max distance (blocks) at which a spotted creeper goes stealth").defineInRange("creeper_stealth_range", 24, 6, 64);
        BUILDER.pop();
        SPEC = BUILDER.build();

        // Must come last: Common's field initialisers read the values defined above.
        COMMON = new Common();
    }

    private SmartMobsConfig() {}
}
