package com.smartmobs.events;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.item.Item;
import com.smartmobs.SmartMobs;
import com.smartmobs.memory.ModAttachments;
import com.smartmobs.memory.PlayerBehavior;
import com.smartmobs.util.PlayerScanner;
import com.smartmobs.util.WeaponClass;

@EventBusSubscriber(modid = SmartMobs.MODID, bus = EventBusSubscriber.Bus.GAME)
public class PlayerObservationEvents {

    @SubscribeEvent
    public static void onPlayerDamageEntity(LivingDamageEvent.Post event) {
        Entity source = event.getSource().getEntity();
        if (!(source instanceof Player player) || player.level().isClientSide()) {
            return;
        }
        // only fights against hostile mobs teach the mobs something
        if (!(event.getEntity() instanceof Monster)) {
            return;
        }

        try {
            PlayerBehavior behavior = player.getData(ModAttachments.PLAYER_BEHAVIOR);
            if (behavior == null) {
                behavior = new PlayerBehavior();
            }

            Entity direct = event.getSource().getDirectEntity();
            Item held = player.getMainHandItem().getItem();
            if (direct instanceof ThrownTrident || held instanceof TridentItem) {
                behavior.increaseProjectileUsage();
            } else if (direct instanceof AbstractArrow || held instanceof BowItem || held instanceof CrossbowItem) {
                behavior.increaseRangedUsage();
            } else if (PlayerScanner.classify(player.getMainHandItem()) == WeaponClass.MELEE) {
                behavior.increaseMeleeUsage();
            }

            // fighting from above
            if (player.getY() > event.getEntity().getY() + 2.0) {
                behavior.increaseHighGroundUsage();
            }

            player.setData(ModAttachments.PLAYER_BEHAVIOR, behavior);
        } catch (Exception e) {
            // Silently fail
        }
    }

    @SubscribeEvent
    public static void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide()) {
            return;
        }

        try {
            PlayerBehavior behavior = player.getData(ModAttachments.PLAYER_BEHAVIOR);
            if (behavior == null) {
                behavior = new PlayerBehavior();
            }

            behavior.increaseBuildingUsage();

            // Pillar-up detection: block placed directly under the player's own feet
            BlockPos placed = event.getPos();
            if (placed.getX() == Mth.floor(player.getX())
                    && placed.getZ() == Mth.floor(player.getZ())
                    && placed.getY() < player.getY()
                    && placed.getY() >= player.getY() - 2.0) {
                behavior.recordPillarBlock(player.level().getGameTime());
            }
            player.setData(ModAttachments.PLAYER_BEHAVIOR, behavior);
        } catch (Exception e) {
            // Silently fail
        }
    }

    /** Mobs slowly forget: every 10 s the remembered behaviour fades a little. */
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide() || player.tickCount % 200 != 0) {
            return;
        }
        try {
            PlayerBehavior behavior = player.getData(ModAttachments.PLAYER_BEHAVIOR);
            if (behavior != null) {
                behavior.decay(1.0f);
                player.setData(ModAttachments.PLAYER_BEHAVIOR, behavior);
            }
        } catch (Exception e) {
            // Silently fail
        }
    }
}
