package com.smartmobs.events;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Monster;
import com.smartmobs.SmartMobs;
import com.smartmobs.adaptation.MobProfiles;
import com.smartmobs.ai.AdaptiveGoal;
import com.smartmobs.ai.CreeperStealthGoal;
import com.smartmobs.ai.PillarBreakerGoal;
import com.smartmobs.ai.WeaponReactionGoal;
import com.smartmobs.config.SmartMobsConfig;

@EventBusSubscriber(modid = SmartMobs.MODID, bus = EventBusSubscriber.Bus.GAME)
public class MobGoalEvents {

    @SubscribeEvent
    public static void onMobJoinLevel(EntityJoinLevelEvent event) {
        // Goals only matter on the logical server
        if (event.getLevel().isClientSide()) {
            return;
        }
        if (!SmartMobsConfig.COMMON.enabled.get()) {
            return;
        }

        // Iron golem: learns to break the blocks under a player who pillars out of reach.
        // Priority 0 so it overrides the vanilla melee goal (priority 1) while active.
        if (event.getEntity() instanceof IronGolem golem) {
            if (!hasGoal(golem, PillarBreakerGoal.class)) {
                golem.goalSelector.addGoal(0, new PillarBreakerGoal(golem));
            }
            return;
        }

        if (!(event.getEntity() instanceof Monster mob)) {
            return;
        }
        if (!MobProfiles.isSupportedMob(mob)) {
            return;
        }

        // Creeper: spotted -> invisible, sneaks up, shows itself right before exploding.
        // Priority 3: below the vanilla swell goal (2), so the fuse always wins over the stealth walk.
        if (mob instanceof Creeper creeper) {
            if (!hasGoal(creeper, CreeperStealthGoal.class)) {
                creeper.goalSelector.addGoal(3, new CreeperStealthGoal(creeper));
            }
            return;
        }

        // Everyone else: instant reaction to the player's weapon (priority 0) + learned strategies (priority 1).
        // Both sit above the vanilla attack goals (priority 2-4) but only run for a limited time.
        if (!hasGoal(mob, WeaponReactionGoal.class)) {
            WeaponReactionGoal reaction = new WeaponReactionGoal(mob);
            mob.goalSelector.addGoal(0, reaction);
            if (!hasGoal(mob, AdaptiveGoal.class)) {
                mob.goalSelector.addGoal(1, new AdaptiveGoal(mob, reaction));
            }
        }
    }

    private static boolean hasGoal(Mob mob, Class<? extends Goal> type) {
        for (WrappedGoal wrapped : mob.goalSelector.getAvailableGoals()) {
            if (type.isInstance(wrapped.getGoal())) {
                return true;
            }
        }
        return false;
    }
}
