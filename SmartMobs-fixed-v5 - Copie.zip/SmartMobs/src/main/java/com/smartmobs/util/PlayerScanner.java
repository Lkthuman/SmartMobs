package com.smartmobs.util;

import com.smartmobs.memory.ModAttachments;
import com.smartmobs.memory.PlayerBehavior;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.MaceItem;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.phys.Vec3;

/** Helpers that let a mob "look at" a player: what he holds, whether he is looking back... */
public final class PlayerScanner {

    private PlayerScanner() {}

    /** Classifies what the player is currently holding / doing. */
    public static WeaponClass classify(Player player) {
        if (player.isBlocking()) {
            return WeaponClass.SHIELD;
        }
        WeaponClass main = classify(player.getMainHandItem());
        if (main == WeaponClass.MELEE || main == WeaponClass.RANGED || main == WeaponClass.BLOCKS
                || main == WeaponClass.SHIELD) {
            return main;
        }
        WeaponClass off = classify(player.getOffhandItem());
        if (off == WeaponClass.SHIELD || off == WeaponClass.RANGED) {
            return off;
        }
        return main;
    }

    public static WeaponClass classify(ItemStack stack) {
        if (stack.isEmpty()) {
            return WeaponClass.FIST;
        }
        Item item = stack.getItem();
        if (item instanceof BowItem || item instanceof CrossbowItem || item instanceof TridentItem) {
            return WeaponClass.RANGED;
        }
        if (item instanceof SwordItem || item instanceof AxeItem || item instanceof MaceItem) {
            return WeaponClass.MELEE;
        }
        if (item instanceof ShieldItem) {
            return WeaponClass.SHIELD;
        }
        if (item instanceof BlockItem) {
            return WeaponClass.BLOCKS;
        }
        return WeaponClass.OTHER;
    }

    /**
     * True when {@code target} is inside the cone the player is looking at.
     *
     * @param minDot cosine of the half angle (0.85 is roughly a 32 degree cone)
     */
    public static boolean isLookingAt(Player player, Entity target, double minDot) {
        Vec3 eye = player.getEyePosition();
        Vec3 to = target.getBoundingBox().getCenter().subtract(eye);
        double length = to.length();
        if (length < 1.0E-4) {
            return true;
        }
        Vec3 look = player.getViewVector(1.0F);
        return look.dot(to.scale(1.0 / length)) >= minDot;
    }

    /** The direction the player faces, flattened on the XZ plane and normalised. */
    public static Vec3 horizontalLook(Player player) {
        Vec3 look = player.getLookAngle();
        double length = Math.sqrt(look.x * look.x + look.z * look.z);
        if (length < 1.0E-4) {
            return new Vec3(0.0, 0.0, 1.0);
        }
        return new Vec3(look.x / length, 0.0, look.z / length);
    }

    /** Unit vector on the XZ plane going from one entity to another (zero vector if they overlap). */
    public static Vec3 flatDirection(Entity from, Entity to) {
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length < 1.0E-4) {
            return Vec3.ZERO;
        }
        return new Vec3(dx / length, 0.0, dz / length);
    }

    /** Never returns null, even if the attachment is unavailable. */
    public static PlayerBehavior behaviorOf(Player player) {
        try {
            PlayerBehavior behavior = player.getData(ModAttachments.PLAYER_BEHAVIOR);
            if (behavior != null) {
                return behavior;
            }
        } catch (Exception ignored) {
            // attachment not available
        }
        return new PlayerBehavior();
    }
}
