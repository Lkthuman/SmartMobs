package com.smartmobs.util;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Finds a spot near a mob that the player cannot see (behind a wall, a tree, a pillar...). */
public final class CoverFinder {

    private CoverFinder() {}

    /** @return a standable position hidden from the player's eyes, or null if there is none nearby. */
    public static BlockPos find(Mob mob, Player player, int radius) {
        Level level = mob.level();
        Vec3 playerEye = player.getEyePosition();
        BlockPos origin = mob.blockPosition();
        BlockPos best = null;
        double bestDistance = Double.MAX_VALUE;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = -1; dy <= 1; dy++) {
                    BlockPos pos = origin.offset(dx, dy, dz);
                    double distance = mob.distanceToSqr(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
                    if (distance >= bestDistance) {
                        continue;
                    }
                    // keep a minimum distance from the player
                    if (player.distanceToSqr(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5) < 9.0) {
                        continue;
                    }
                    if (!isStandable(level, pos)) {
                        continue;
                    }
                    Vec3 eye = new Vec3(pos.getX() + 0.5, pos.getY() + 1.5, pos.getZ() + 0.5);
                    BlockHitResult hit = level.clip(
                            new ClipContext(playerEye, eye, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
                    if (hit.getType() == HitResult.Type.MISS) {
                        continue; // the player can see this spot
                    }
                    best = pos;
                    bestDistance = distance;
                }
            }
        }
        return best;
    }

    private static boolean isStandable(Level level, BlockPos pos) {
        BlockState feet = level.getBlockState(pos);
        BlockState head = level.getBlockState(pos.above());
        BlockState floor = level.getBlockState(pos.below());
        return feet.getCollisionShape(level, pos).isEmpty()
                && head.getCollisionShape(level, pos.above()).isEmpty()
                && !floor.getCollisionShape(level, pos.below()).isEmpty()
                && level.getFluidState(pos).isEmpty();
    }
}
