package com.smartmobs.util;

/** What a mob "sees" in the player's hands. */
public enum WeaponClass {
    /** Empty hand. */
    FIST,
    /** Sword, axe, mace... */
    MELEE,
    /** Bow, crossbow, trident. */
    RANGED,
    /** Shield (held or actively blocking). */
    SHIELD,
    /** Any placeable block (pillar-up / bridging material). */
    BLOCKS,
    /** Anything else (food, tools, ...). */
    OTHER
}
