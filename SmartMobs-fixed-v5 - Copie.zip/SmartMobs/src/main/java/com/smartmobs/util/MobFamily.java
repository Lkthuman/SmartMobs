package com.smartmobs.util;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.monster.Pillager;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.entity.monster.Stray;
import net.minecraft.world.entity.monster.Vindicator;
import net.minecraft.world.entity.monster.Witch;
import net.minecraft.world.entity.monster.Zombie;

/** Broad combat families: decides which reactions / strategies make sense for a mob. */
public enum MobFamily {
    /** Walks up to the player and hits him (zombies, spiders, vindicators, endermen). */
    MELEE,
    /** Fights from a distance (skeletons, strays, pillagers, witches). */
    RANGED,
    /** Explodes: has its own stealth behaviour. */
    CREEPER,
    OTHER;

    public static MobFamily of(Mob mob) {
        if (mob instanceof Creeper) {
            return CREEPER;
        }
        if (mob instanceof Skeleton || mob instanceof Stray || mob instanceof Pillager || mob instanceof Witch) {
            return RANGED;
        }
        if (mob instanceof Zombie || mob instanceof Spider || mob instanceof Vindicator || mob instanceof EnderMan) {
            return MELEE;
        }
        return OTHER;
    }
}
