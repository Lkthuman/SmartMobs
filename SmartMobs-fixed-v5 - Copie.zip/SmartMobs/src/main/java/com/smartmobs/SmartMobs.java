package com.smartmobs;

import com.smartmobs.config.SmartMobsConfig;
import com.smartmobs.memory.ModAttachments;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(SmartMobs.MODID)
public class SmartMobs {
    public static final String MODID = "smartmobs";
    private static final Logger LOGGER = LoggerFactory.getLogger(SmartMobs.class);

    public SmartMobs(IEventBus modEventBus, ModContainer modContainer) {
        modContainer.registerConfig(ModConfig.Type.COMMON, SmartMobsConfig.SPEC);
        ModAttachments.ATTACHMENTS.register(modEventBus);
        LOGGER.info("SmartMobs mod loaded!");
    }
}
