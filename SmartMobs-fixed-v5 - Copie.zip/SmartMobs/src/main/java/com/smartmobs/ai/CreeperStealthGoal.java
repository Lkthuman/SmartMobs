package com.smartmobs.ai;

import com.smartmobs.config.SmartMobsConfig;
import com.smartmobs.util.PlayerScanner;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Creeper stealth.
 *
 * When a player LOOKS at a creeper that is targeting him (the creeper "sees that it has been seen"),
 * the creeper turns invisible and sneaks up on the player, trying to come in from behind.
 * It becomes visible again right before it explodes: just before the vanilla fuse starts
 * (distance &lt;= REVEAL_DISTANCE), when it is hurt, or when the fuse is lit.
 */
public class CreeperStealthGoal extends Goal {

    /** The vanilla swell goal starts at 3 blocks: reveal just before. */
    private static final double REVEAL_DISTANCE = 3.6;
    /** Too close to bother hiding: the player would see the creeper pop in/out. */
    private static final double MIN_HIDE_DISTANCE = 6.0;
    private static final int MAX_STEALTH_TICKS = 600;
    private static final int COOLDOWN_AFTER_REVEAL = 200;
    /** Cone (cosine) in which the player must look to "see" the creeper. */
    private static final double SEEN_DOT = 0.85;

    private final Creeper creeper;
    private Player target;
    private boolean hidden;
    private boolean ownsInvisibility;
    private int activeTicks;
    private int moveTimer;
    private int nextAllowedTick;
    private int scanDelay;

    public CreeperStealthGoal(Creeper creeper) {
        this.creeper = creeper;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public boolean canUse() {
        if (--scanDelay > 0) {
            return false;
        }
        scanDelay = 2;

        if (creeper.tickCount < nextAllowedTick) {
            return false;
        }
        if (!SmartMobsConfig.COMMON.enabled.get() || !SmartMobsConfig.COMMON.creeperStealth.get()) {
            return false;
        }
        if (!(creeper.getTarget() instanceof Player player) || !player.isAlive() || player.isSpectator()) {
            return false;
        }
        if (creeper.isIgnited() || creeper.getSwellDir() > 0) {
            return false;
        }
        double distance = creeper.distanceTo(player);
        if (distance < MIN_HIDE_DISTANCE || distance > SmartMobsConfig.COMMON.creeperStealthRange.get()) {
            return false;
        }
        // both ways: the creeper sees the player AND the player is looking at the creeper
        if (!creeper.hasLineOfSight(player) || !player.hasLineOfSight(creeper)) {
            return false;
        }
        if (!PlayerScanner.isLookingAt(player, creeper, SEEN_DOT)) {
            return false;
        }
        this.target = player;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        LivingEntity current = creeper.getTarget();
        if (!(current instanceof Player player) || !player.isAlive() || player.isSpectator()) {
            return false;
        }
        target = player;
        if (activeTicks > MAX_STEALTH_TICKS) {
            return false;
        }
        // about to explode -> show yourself
        if (creeper.isIgnited() || creeper.getSwellDir() > 0) {
            return false;
        }
        if (creeper.distanceTo(player) <= REVEAL_DISTANCE) {
            return false;
        }
        // got hit -> cover blown
        if (creeper.hurtTime > 0) {
            return false;
        }
        return creeper.distanceTo(player) <= SmartMobsConfig.COMMON.creeperStealthRange.get() * 1.5;
    }

    @Override
    public void start() {
        activeTicks = 0;
        moveTimer = 0;
        hide();
    }

    @Override
    public void tick() {
        if (target == null) {
            return;
        }
        activeTicks++;
        creeper.getLookControl().setLookAt(target, 30.0F, 30.0F);

        // keep the (short) invisibility effect alive; it vanishes by itself if the goal is ever lost
        if (activeTicks % 10 == 0 || !creeper.hasEffect(MobEffects.INVISIBILITY)) {
            applyInvisibility();
        }

        if (--moveTimer <= 0) {
            moveTimer = 6;
            Vec3 destination = stalkDestination();
            creeper.getNavigation().moveTo(destination.x, destination.y, destination.z, 1.0);
        }
    }

    @Override
    public void stop() {
        reveal();
        creeper.getNavigation().stop();
        nextAllowedTick = creeper.tickCount + COOLDOWN_AFTER_REVEAL;
        target = null;
    }

    // ------------------------------------------------------------------ helpers

    /** Far away: slip round to the player's back. Close: go straight for him. */
    private Vec3 stalkDestination() {
        double distance = creeper.distanceTo(target);
        if (distance > 9.0) {
            Vec3 look = PlayerScanner.horizontalLook(target);
            return target.position().subtract(look.scale(3.0));
        }
        return target.position();
    }

    private void hide() {
        ownsInvisibility = !creeper.hasEffect(MobEffects.INVISIBILITY);
        applyInvisibility();
        hidden = true;
        puff(6);
    }

    private void reveal() {
        if (!hidden) {
            return;
        }
        hidden = false;
        if (ownsInvisibility) {
            creeper.removeEffect(MobEffects.INVISIBILITY);
        }
        ownsInvisibility = false;
        puff(4);
    }

    private void applyInvisibility() {
        // no ambient flag, no particles: nothing gives the creeper away
        creeper.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 30, 0, false, false));
    }

    private void puff(int count) {
        if (creeper.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.POOF,
                    creeper.getX(), creeper.getY() + 0.8, creeper.getZ(),
                    count, 0.3, 0.4, 0.3, 0.01);
        }
    }

    // ------------------------------------------------------------------ debug accessors

    public boolean isHidden() {
        return hidden;
    }
}
