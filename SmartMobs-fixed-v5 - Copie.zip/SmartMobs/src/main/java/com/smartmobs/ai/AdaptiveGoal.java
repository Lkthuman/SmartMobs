package com.smartmobs.ai;

import com.smartmobs.adaptation.AdaptationStrategy;
import com.smartmobs.adaptation.MobMemory;
import com.smartmobs.adaptation.StrategyManager;
import com.smartmobs.config.SmartMobsConfig;
import com.smartmobs.learning.LearningMoments;
import com.smartmobs.memory.PlayerBehavior;
import com.smartmobs.util.PlayerScanner;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;

/**
 * Learning brain of a mob.
 *
 * While idle it only OBSERVES the player (learning bar, adaptation level, "am I stuck?" detection) and lets the
 * vanilla goals fight. When it decides to adapt, the chosen strategy takes EXCLUSIVE control of the mob's movement
 * for a limited time (MOVE flag), then hands it back to the vanilla attack goal.
 */
public class AdaptiveGoal extends Goal {

    private static final int MAX_STRATEGY_TICKS = 300;

    private final Mob mob;
    private final WeaponReactionGoal reaction;
    private final StrategyManager strategyManager = new StrategyManager();

    private MobMemory mobMemory;
    private Player target;
    private AdaptationStrategy current;
    private double startDistance;
    private int runTicks;
    private boolean finished;

    private int selectDelay;
    private int observeDelay;
    private int stuckChecks;

    public AdaptiveGoal(Mob mob) {
        this(mob, null);
    }

    public AdaptiveGoal(Mob mob, WeaponReactionGoal reaction) {
        this.mob = mob;
        this.reaction = reaction;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public boolean canUse() {
        // not running here: drop anything left over from a start that was blocked by a conflicting goal
        current = null;
        target = null;
        if (!SmartMobsConfig.COMMON.enabled.get()) {
            return false;
        }
        // an instant weapon reaction always has priority
        if (reaction != null && reaction.isActive()) {
            return false;
        }
        if (!(mob.getTarget() instanceof Player player) || !player.isAlive() || player.isSpectator()) {
            return false;
        }
        if (mob.distanceTo(player) > SmartMobsConfig.COMMON.observationRange.get()) {
            return false;
        }

        ensureMemory(player);
        observe(player);

        if (--selectDelay > 0) {
            return false;
        }
        selectDelay = 5;

        if (mob.getRandom().nextInt(100) >= SmartMobsConfig.COMMON.adaptationChance.get()) {
            return false;
        }
        AdaptationStrategy strategy = strategyManager.selectStrategy(mob, player, mobMemory);
        if (strategy == null) {
            return false;
        }
        this.target = player;
        this.current = strategy;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return !finished
                && current != null
                && target != null
                && target.isAlive()
                && !target.isSpectator()
                && mob.getTarget() == target
                && (reaction == null || !reaction.isActive());
    }

    @Override
    public void start() {
        runTicks = 0;
        finished = false;
        startDistance = mob.distanceTo(target);
        current.onStart(mob, target);
        mobMemory.setCurrentStrategy(current.getType(), mob.level().getGameTime());
        LearningMoments.observationAnimation(mob, target);
    }

    @Override
    public void tick() {
        if (target == null || current == null) {
            return;
        }
        runTicks++;
        mob.getLookControl().setLookAt(target, 30.0F, 30.0F);

        current.execute(mob, target);
        if (runTicks > MAX_STRATEGY_TICKS || !current.shouldContinue(mob, target)) {
            finished = true;
        }
        observe(target);
    }

    @Override
    public void stop() {
        if (current != null && mobMemory != null) {
            boolean success = target != null && current.wasSuccessful(mob, target, startDistance);
            if (success) {
                mobMemory.recordStrategySuccess(current.getType());
            } else {
                mobMemory.recordStrategyFailure(current.getType());
            }
            mobMemory.markStrategyEnded(current.getType(), mob.level().getGameTime());
            current.onComplete(mob);
        }
        strategyManager.clearStrategy();
        mob.getNavigation().stop();
        current = null;
        target = null;
        finished = false;
    }

    @Override
    public boolean isInterruptable() {
        return true;
    }

    // ------------------------------------------------------------------ observation / learning

    private void ensureMemory(Player player) {
        if (mobMemory == null || !mobMemory.getPlayerId().equals(player.getUUID())) {
            mobMemory = new MobMemory(mob.getUUID(), player.getUUID());
        }
    }

    /** Runs roughly every 10 ticks: learning bar, adaptation level and stuck detection. */
    private void observe(Player player) {
        if (mobMemory == null || --observeDelay > 0) {
            return;
        }
        observeDelay = 5;

        // 1. what the player has been doing -> level 0..3
        PlayerBehavior behavior = PlayerScanner.behaviorOf(player);
        float total = behavior.getMeleeUsage() + behavior.getRangedUsage() + behavior.getProjectileUsage()
                + behavior.getBuildingUsage() + behavior.getHighGroundUsage();
        int behaviorLevel = 0;
        if (total > 0.25f) behaviorLevel = 1;
        if (total > 0.50f) behaviorLevel = 2;
        if (total > 0.75f) behaviorLevel = 3;

        // 2. simply watching the player teaches the mob (slowly)
        if (mob.hasLineOfSight(player)) {
            mobMemory.increaseLearningProgress(Math.max(1, SmartMobsConfig.COMMON.learningSpeed.get() / 2));
            if (mobMemory.consumeLearned()) {
                LearningMoments.adaptationFlashAnimation(mob);
            }
        }
        int maxLevel = SmartMobsConfig.COMMON.maxAdaptationLevel.get();
        mobMemory.setAdaptationLevel(Math.min(maxLevel, behaviorLevel + mobMemory.getLearnedLevels()));

        // 3. "I cannot get to him": standing still, far from the player, with nothing left to follow
        double distance = mob.distanceTo(player);
        if (current == null && mob.getNavigation().isDone() && distance > 3.5) {
            if (++stuckChecks >= 3) {
                stuckChecks = 0;
                mobMemory.recordPathfindingFailure();
                if (mobMemory.getFailedPathfindingAttempts() == 2) {
                    LearningMoments.failureAnimation(mob);
                }
            }
        } else if (!mob.getNavigation().isDone()) {
            stuckChecks = 0;
            mobMemory.decayPathfindingFailure();
        } else if (distance <= 3.5) {
            stuckChecks = 0;
            mobMemory.resetPathfindingFailures();
        }
    }

    // ------------------------------------------------------------------ debug accessors

    public MobMemory getMobMemory() {
        return mobMemory;
    }

    public String getCurrentStrategyName() {
        return current == null ? "None" : current.getName();
    }
}
