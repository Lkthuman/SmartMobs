package com.smartmobs.ai;

import com.smartmobs.config.SmartMobsConfig;
import com.smartmobs.learning.AdvancedAnimations;
import com.smartmobs.learning.LearningMoments;
import com.smartmobs.util.CoverFinder;
import com.smartmobs.util.MobFamily;
import com.smartmobs.util.PlayerScanner;
import com.smartmobs.util.WeaponClass;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Instant reaction to the weapon the player holds.
 *
 * As soon as a mob that is targeting a player SEES what he holds (no learning delay), it picks a counter:
 * <ul>
 *   <li>melee mobs vs sword/axe: flank from the side, then charge</li>
 *   <li>melee mobs vs bow/crossbow/trident: zigzag rush</li>
 *   <li>melee mobs vs shield: circle round to his back</li>
 *   <li>melee mobs vs blocks in hand: rush before he can pillar up</li>
 *   <li>ranged mobs vs sword/axe: kite (back off, then shoot)</li>
 *   <li>ranged mobs vs bow: take cover, peek out later</li>
 *   <li>ranged mobs vs shield: get behind the shield</li>
 * </ul>
 * It re-adapts immediately when the player swaps item (a flash of particles shows the mob understood).
 */
public class WeaponReactionGoal extends Goal {

    public enum Reaction { NONE, FLANK_SIDE, ZIGZAG, FLANK_BEHIND, RUSH, KITE, COVER }

    private final Mob mob;
    private final MobFamily family;

    private Player target;
    private Reaction reaction = Reaction.NONE;
    private Reaction pendingReaction = Reaction.NONE;
    private WeaponClass pendingWeapon = WeaponClass.OTHER;
    private WeaponClass lastSeen;

    private boolean active;
    private boolean done;
    private int activeTicks;
    private int maxTicks;
    private int moveTimer;
    private int holdTicks;
    private int sideSign = 1;
    private int nextAllowedTick;
    private int scanDelay;
    private BlockPos coverPos;

    public WeaponReactionGoal(Mob mob) {
        this.mob = mob;
        this.family = MobFamily.of(mob);
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    // ------------------------------------------------------------------ Goal API

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public boolean canUse() {
        if (--scanDelay > 0) {
            return false;
        }
        scanDelay = 3;

        if (mob.tickCount < nextAllowedTick) {
            return false;
        }
        if (!SmartMobsConfig.COMMON.enabled.get() || !SmartMobsConfig.COMMON.weaponReaction.get()) {
            return false;
        }
        if (!(mob.getTarget() instanceof Player player) || !player.isAlive() || player.isSpectator()) {
            return false;
        }
        // the mob must actually SEE the player (and so what he is holding)
        if (!mob.hasLineOfSight(player)) {
            return false;
        }
        double range = Math.min(24.0, SmartMobsConfig.COMMON.observationRange.get());
        double distance = mob.distanceTo(player);
        if (distance > range) {
            return false;
        }

        WeaponClass weapon = PlayerScanner.classify(player);
        Reaction chosen = decide(weapon, distance);
        if (chosen == Reaction.NONE) {
            lastSeen = weapon;
            return false;
        }
        this.target = player;
        this.pendingReaction = chosen;
        this.pendingWeapon = weapon;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return !done && target != null && target.isAlive() && !target.isSpectator() && activeTicks < maxTicks;
    }

    @Override
    public void start() {
        active = true;
        done = false;
        activeTicks = 0;
        moveTimer = 0;
        holdTicks = 0;
        coverPos = null;
        reaction = pendingReaction;
        sideSign = mob.getRandom().nextBoolean() ? 1 : -1;
        maxTicks = switch (reaction) {
            case FLANK_SIDE -> 110;
            case ZIGZAG -> 120;
            case FLANK_BEHIND -> 100;
            case RUSH -> 80;
            case KITE -> 50;
            case COVER -> 90;
            default -> 60;
        };

        // visible "I understood" moment, only when the weapon changed
        if (lastSeen != pendingWeapon) {
            LearningMoments.adaptationFlashAnimation(mob);
        }
        lastSeen = pendingWeapon;

        if (reaction == Reaction.KITE || reaction == Reaction.COVER) {
            AdvancedAnimations.nervousAnimation(mob);
        } else {
            AdvancedAnimations.focusAnimation(mob, target);
        }

        if (reaction == Reaction.COVER) {
            coverPos = CoverFinder.find(mob, target, 7);
            if (coverPos == null) {
                done = true; // nowhere to hide
            }
        }
    }

    @Override
    public void tick() {
        if (target == null) {
            return;
        }
        activeTicks++;
        mob.getLookControl().setLookAt(target, 30.0F, 30.0F);

        boolean repath = --moveTimer <= 0;
        if (repath) {
            moveTimer = 6;
        }
        double distance = mob.distanceTo(target);

        switch (reaction) {
            case FLANK_SIDE -> tickFlankSide(distance, repath);
            case ZIGZAG -> tickZigzag(distance, repath);
            case FLANK_BEHIND -> tickFlankBehind(distance, repath);
            case RUSH -> tickRush(distance, repath);
            case KITE -> tickKite(distance, repath);
            case COVER -> tickCover(repath);
            default -> done = true;
        }
    }

    @Override
    public void stop() {
        active = false;
        mob.getNavigation().stop();
        int cooldown = switch (reaction) {
            case FLANK_SIDE -> 140;
            case ZIGZAG -> 120;
            case FLANK_BEHIND -> 160;
            case RUSH -> 100;
            case KITE -> 60;
            case COVER -> 180;
            default -> 100;
        };
        nextAllowedTick = mob.tickCount + cooldown;
        reaction = Reaction.NONE;
        target = null;
        coverPos = null;
    }

    // ------------------------------------------------------------------ decision

    private Reaction decide(WeaponClass weapon, double distance) {
        if (family == MobFamily.MELEE) {
            if (distance <= 3.5) {
                return Reaction.NONE; // already in melee range: vanilla attack
            }
            switch (weapon) {
                case MELEE:
                    return Reaction.FLANK_SIDE;
                case RANGED:
                    return Reaction.ZIGZAG;
                case SHIELD:
                    return Reaction.FLANK_BEHIND;
                case BLOCKS:
                    return Reaction.RUSH;
                default:
                    return Reaction.NONE;
            }
        }
        if (family == MobFamily.RANGED) {
            switch (weapon) {
                case MELEE:
                    return distance < 8.0 ? Reaction.KITE : Reaction.NONE;
                case RANGED:
                    return distance >= 6.0 ? Reaction.COVER : Reaction.KITE;
                case SHIELD:
                    return distance > 6.0 ? Reaction.FLANK_BEHIND : Reaction.KITE;
                default:
                    return Reaction.NONE;
            }
        }
        return Reaction.NONE;
    }

    // ------------------------------------------------------------------ reactions

    /** Go round to the side first, then charge. */
    private void tickFlankSide(double distance, boolean repath) {
        if (distance <= 2.6) {
            done = true;
            return;
        }
        Vec3 destination;
        if (activeTicks < 35 && distance > 5.0) {
            Vec3 dir = PlayerScanner.flatDirection(mob, target);
            Vec3 perpendicular = new Vec3(-dir.z * sideSign, 0.0, dir.x * sideSign);
            destination = target.position().add(perpendicular.scale(4.0));
        } else {
            destination = target.position();
        }
        if (repath) {
            mob.getNavigation().moveTo(destination.x, destination.y, destination.z, 1.15);
        }
    }

    /** Weave left and right so arrows miss. */
    private void tickZigzag(double distance, boolean repath) {
        if (distance <= 2.8) {
            done = true;
            return;
        }
        Vec3 dir = PlayerScanner.flatDirection(mob, target);
        Vec3 perpendicular = new Vec3(-dir.z, 0.0, dir.x);
        double offset = Math.sin(activeTicks * 0.3) * 3.0;
        Vec3 destination = target.position().add(perpendicular.scale(offset));
        if (repath) {
            mob.getNavigation().moveTo(destination.x, destination.y, destination.z, 1.3);
        }
    }

    /** Get behind the player (and his shield). Ranged mobs only go to ~7 blocks behind. */
    private void tickFlankBehind(double distance, boolean repath) {
        double back = family == MobFamily.RANGED ? 7.0 : 2.0;
        Vec3 destination = target.position().subtract(PlayerScanner.horizontalLook(target).scale(back));
        if (family == MobFamily.MELEE) {
            if (distance <= 2.6) {
                done = true;
                return;
            }
        } else {
            double dx = destination.x - mob.getX();
            double dz = destination.z - mob.getZ();
            if (Math.sqrt(dx * dx + dz * dz) <= 2.5) {
                done = true;
                return;
            }
        }
        if (repath) {
            mob.getNavigation().moveTo(destination.x, destination.y, destination.z, 1.2);
        }
    }

    /** Straight, fast: do not let the player build a tower. */
    private void tickRush(double distance, boolean repath) {
        if (distance <= 2.5) {
            done = true;
            return;
        }
        if (repath) {
            mob.getNavigation().moveTo(target, 1.35);
        }
    }

    /** Back off from a melee player (then the vanilla goal shoots again). */
    private void tickKite(double distance, boolean repath) {
        if (distance >= 11.0) {
            done = true;
            return;
        }
        PathNavigation navigation = mob.getNavigation();
        if (activeTicks > 12 && navigation.isDone() && distance < 4.0) {
            done = true; // cornered
            return;
        }
        if (repath) {
            Vec3 away = PlayerScanner.flatDirection(target, mob);
            Vec3 side = new Vec3(-away.z, 0.0, away.x).scale(sideSign * 2.0);
            Vec3 destination = mob.position().add(away.scale(7.0)).add(side);
            navigation.moveTo(destination.x, destination.y, destination.z, 1.3);
        }
    }

    /** Hide behind a block, wait a moment, then peek out again. */
    private void tickCover(boolean repath) {
        if (coverPos == null) {
            done = true;
            return;
        }
        double cx = coverPos.getX() + 0.5;
        double cz = coverPos.getZ() + 0.5;
        if (mob.distanceToSqr(cx, coverPos.getY(), cz) <= 2.25) {
            mob.getNavigation().stop();
            holdTicks++;
            if (holdTicks > 30) {
                done = true;
            }
        } else if (repath) {
            mob.getNavigation().moveTo(cx, coverPos.getY(), cz, 1.25);
        }
    }

    // ------------------------------------------------------------------ accessors (debug / other goals)

    public boolean isActive() {
        return active;
    }

    public String getReactionName() {
        return reaction.name();
    }

    public WeaponClass getLastSeen() {
        return lastSeen;
    }
}
