package com.smartmobs.ai;

import com.smartmobs.config.SmartMobsConfig;
import com.smartmobs.learning.AdvancedAnimations;
import com.smartmobs.memory.ModAttachments;
import com.smartmobs.memory.PlayerBehavior;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

/**
 * Anti-pillar behaviour for the iron golem.
 *
 * When a player hits the golem and then climbs out of its reach by placing blocks under
 * their feet (pillar-up), the golem works out that it cannot walk to the player, walks to the
 * base of the pillar and starts BREAKING THE BLOCKS THAT SUPPORT THE PLAYER (with the vanilla
 * crack animation) until the player comes back down within melee range. The vanilla
 * melee goal then takes over again.
 */
public class PillarBreakerGoal extends Goal {

    /** Player feet this many blocks above the golem's feet = out of melee range (golem is 2.7 tall). */
    private static final double ELEVATION_THRESHOLD = 2.3;
    /** Distance (eye -> block centre) the golem can reach to break a block. */
    private static final double REACH = 4.6;
    private static final int GIVE_UP_TICKS = 600;
    private static final int COOLDOWN_AFTER_GIVE_UP = 100;

    private final Mob mob;
    private Player target;
    private BlockPos breakingPos;
    private int breakProgress;
    private int breakNeeded;
    private int activeTicks;
    private int airTicks;
    private int cooldown;
    private int scanDelay;

    public PillarBreakerGoal(Mob mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    // ------------------------------------------------------------------ Goal API

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public boolean canUse() {
        if (cooldown > 0) {
            cooldown--;
            return false;
        }
        if (--scanDelay > 0) {
            return false;
        }
        scanDelay = 10;

        if (!(mob.level() instanceof ServerLevel level)) {
            return false;
        }
        if (!SmartMobsConfig.COMMON.enabled.get() || !SmartMobsConfig.COMMON.golemBreakBlocks.get()) {
            return false;
        }
        if (!level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            return false;
        }

        Player p = findTarget();
        if (p == null || !isElevated(p)) {
            return false;
        }
        // If the golem can simply walk to the player (hill, stairs...) vanilla AI handles it.
        if (canWalkTo(p)) {
            return false;
        }
        // Only engage if there is something we are able to break under the player.
        if (findSupports(p).isEmpty()) {
            return false;
        }
        this.target = p;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        if (target == null || !target.isAlive() || target.isSpectator()) {
            return false;
        }
        if (activeTicks > GIVE_UP_TICKS) {
            cooldown = COOLDOWN_AFTER_GIVE_UP;
            return false;
        }
        if (airTicks > 40) {
            return false;
        }
        Player p = findTarget();
        if (p == null) {
            return false;
        }
        target = p;
        return isElevated(target);
    }

    @Override
    public void start() {
        activeTicks = 0;
        airTicks = 0;
        resetBreaking();
        if (mob.getTarget() != target) {
            mob.setTarget(target);
        }
        // "The golem has seen the pillar": thinking animation, bigger 'eureka' if the player really pillared
        boolean sawPillar = false;
        try {
            PlayerBehavior behavior = target.getData(ModAttachments.PLAYER_BEHAVIOR);
            sawPillar = behavior != null && behavior.getPillarCount(target.level().getGameTime()) >= 3;
        } catch (Exception ignored) {
            // attachment unavailable -> not an issue
        }
        if (sawPillar) {
            AdvancedAnimations.discoveryAnimation(mob);
        } else {
            AdvancedAnimations.thinkingAnimation(mob);
        }
    }

    @Override
    public void tick() {
        if (target == null || !(mob.level() instanceof ServerLevel level)) {
            return;
        }
        activeTicks++;
        mob.getLookControl().setLookAt(target, 30.0F, 30.0F);

        List<BlockPos> supports = findSupports(target);
        if (supports.isEmpty()) {
            // player is in the air (jumping / placing) -> just wait next to the pillar
            airTicks++;
            resetBreaking();
            approach();
            return;
        }
        airTicks = 0;

        // keep the block we are already breaking if it still supports the player
        BlockPos chosen = null;
        if (breakingPos != null && supports.contains(breakingPos) && canReachBlock(breakingPos)) {
            chosen = breakingPos;
        } else {
            double best = Double.MAX_VALUE;
            Vec3 eye = mob.getEyePosition();
            for (BlockPos pos : supports) {
                if (!canReachBlock(pos)) {
                    continue;
                }
                double d = eye.distanceToSqr(Vec3.atCenterOf(pos));
                if (d < best) {
                    best = d;
                    chosen = pos;
                }
            }
        }

        if (chosen == null) {
            // nothing within reach yet -> walk to the foot of the pillar
            resetBreaking();
            approach();
            return;
        }

        mob.getNavigation().stop();

        if (!chosen.equals(breakingPos)) {
            resetBreaking();
            breakingPos = chosen;
            breakProgress = 0;
            BlockState state = level.getBlockState(chosen);
            float hardness = state.getDestroySpeed(level, chosen);
            breakNeeded = Mth.clamp((int) (hardness * 15.0F), 10, 100);
        }

        breakProgress++;

        // arm swing + hit sound
        if (breakProgress % 8 == 1 && mob instanceof IronGolem) {
            level.broadcastEntityEvent(mob, (byte) 4);
        }
        if (breakProgress % 6 == 0) {
            BlockState state = level.getBlockState(breakingPos);
            level.playSound(null, breakingPos, state.getSoundType().getHitSound(), SoundSource.BLOCKS, 0.7F, 0.8F);
        }

        // vanilla crack overlay (0..9)
        int stage = Math.min(9, (int) ((float) breakProgress / (float) breakNeeded * 10.0F));
        level.destroyBlockProgress(mob.getId(), breakingPos, stage);

        if (breakProgress >= breakNeeded) {
            BlockPos done = breakingPos;
            level.destroyBlockProgress(mob.getId(), done, -1);
            level.destroyBlock(done, true, mob);
            breakingPos = null;
            breakProgress = 0;
            AdvancedAnimations.blockPlaceAnimation(mob);
        }
    }

    @Override
    public void stop() {
        resetBreaking();
        mob.getNavigation().stop();
        target = null;
    }

    // ------------------------------------------------------------------ helpers

    private Player findTarget() {
        LivingEntity t = mob.getTarget();
        if (t instanceof Player p && p.isAlive() && !p.isSpectator()) {
            return p;
        }
        LivingEntity hurtBy = mob.getLastHurtByMob();
        if (hurtBy instanceof Player p && p.isAlive() && !p.isSpectator()
                && mob.tickCount - mob.getLastHurtByMobTimestamp() < 200) {
            return p;
        }
        return null;
    }

    private boolean isElevated(Player p) {
        if (p.getY() - mob.getY() < ELEVATION_THRESHOLD) {
            return false;
        }
        double dx = p.getX() - mob.getX();
        double dz = p.getZ() - mob.getZ();
        return dx * dx + dz * dz <= 20.0 * 20.0;
    }

    private boolean canWalkTo(Player p) {
        Path path = mob.getNavigation().createPath(p, 0);
        return path != null && path.canReach();
    }

    /** Solid, breakable blocks directly under the player's feet (the ones holding them up). */
    private List<BlockPos> findSupports(Player p) {
        List<BlockPos> list = new ArrayList<>();
        AABB box = p.getBoundingBox();
        int y = Mth.floor(box.minY - 0.05);
        int minX = Mth.floor(box.minX);
        int maxX = Mth.floor(box.maxX - 1.0E-4);
        int minZ = Mth.floor(box.minZ);
        int maxZ = Mth.floor(box.maxZ - 1.0E-4);
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                BlockPos pos = new BlockPos(x, y, z);
                BlockState state = mob.level().getBlockState(pos);
                if (state.isAir() || state.getCollisionShape(mob.level(), pos).isEmpty()) {
                    continue;
                }
                if (state.getDestroySpeed(mob.level(), pos) < 0.0F) {
                    continue; // bedrock & co
                }
                list.add(pos);
            }
        }
        return list;
    }

    private boolean canReachBlock(BlockPos pos) {
        Vec3 eye = mob.getEyePosition();
        Vec3 center = Vec3.atCenterOf(pos);
        if (eye.distanceToSqr(center) > REACH * REACH) {
            return false;
        }
        BlockHitResult hit = mob.level().clip(
                new ClipContext(eye, center, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mob));
        return hit.getType() == HitResult.Type.MISS || hit.getBlockPos().equals(pos);
    }

    /** Walk to a spot right next to the pillar, on the golem's side of it. */
    private void approach() {
        double dx = mob.getX() - target.getX();
        double dz = mob.getZ() - target.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal <= 2.2) {
            mob.getNavigation().stop();
            return;
        }
        if (mob.getNavigation().isDone() || activeTicks % 10 == 0) {
            double nx = dx / horizontal * 1.6;
            double nz = dz / horizontal * 1.6;
            mob.getNavigation().moveTo(target.getX() + nx, mob.getY(), target.getZ() + nz, 1.0);
        }
    }

    private void resetBreaking() {
        if (breakingPos != null && mob.level() instanceof ServerLevel level) {
            level.destroyBlockProgress(mob.getId(), breakingPos, -1);
        }
        breakingPos = null;
        breakProgress = 0;
        breakNeeded = 0;
    }

    // ------------------------------------------------------------------ debug accessors

    public boolean isBreaking() {
        return breakingPos != null;
    }

    public BlockPos getBreakingPos() {
        return breakingPos;
    }

    public int getBreakPercent() {
        return breakNeeded <= 0 ? 0 : Math.min(100, breakProgress * 100 / breakNeeded);
    }
}
